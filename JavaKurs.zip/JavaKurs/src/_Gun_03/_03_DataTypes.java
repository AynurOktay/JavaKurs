package _Gun_03;

public class _03_DataTypes {
    public static void main(String[] args) {

        int sayi; // sadece tam sayi atayabilirim,sdece int kadar yer kaplar
                  //long intì gectigi icin sonuna L yaziyoruz.Yoksa default olur


               //tam sayilar

                byte byteDeger =7;
                short shortDeger =1645;
                int intDeger=250000;
                long longDeger=23234567787676L;

                //ondalikli sayilar
                   double doubleDeger=3.144465343567889;
                   float floatDeger=3.14446785F;

                   char basHarf= 'A';
                   String isim="ismet";
        System.out.println("isim = " + isim);
        System.out.println("basHarf = " + basHarf);
        System.out.println("floatDeger = " + floatDeger);
        System.out.println("doubleDeger = " + doubleDeger);
        System.out.println("longDeger = " + longDeger);
        System.out.println("intDeger = " + intDeger);
        System.out.println("shortDeger = " + shortDeger);
        System.out.println("byteDeger = " + byteDeger);






    }
}
