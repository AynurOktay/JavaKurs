package _Gun_03;

public class _02_Degiskenler {
    public static void main(String[] args) {
        
        int sayi=5;
        
        int kisaKenar=5; 
        int uzunKenar=7;
        int cevre;

        cevre =kisaKenar +uzunKenar +kisaKenar +uzunKenar;
//veya  cevre =(kisaKenar+uzunKenar)*2;

        System.out.println("cevre = " + cevre);

        
    }
}