package _Gun_03;

public class _04_DataTypesMinMax {
    public static void main(String[] args) {






    }
}
