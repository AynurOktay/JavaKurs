package _Gun_03;

public class _06_Ornek2 {
    public static void main(String[] args) {

        //dairenin alanini bul

         double yaricap=4;
         double pi=3.14;
          double alan=pi*yaricap*yaricap;
          double cevre=2*pi*yaricap;




        System.out.println("cevre = " + cevre);
        System.out.println("alan = " + alan);

    }
}
