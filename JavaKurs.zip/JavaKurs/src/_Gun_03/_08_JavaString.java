package _Gun_03;

public class _08_JavaString {
    public static void main(String[] args) {

        String ad="Ismet";
        //String kelimeleri saklamak icin kullanilir.

        String soyad="Temur";

        System.out.println("ad="+ad);

        System.out.println("soyad="+soyad);
        System.out.println("ad ve soyad=" +ad+ " "+soyad);
    }
}
