package _Gun_03;

public class _05_Ornek {
    public static void main(String[] args) {

        int kenar1=4;
        int kenar2=5;
        int cevre=kenar1+kenar1+kenar2+kenar2;
        int alan=kenar1*kenar2;
        System.out.println("alan = " + alan);
        System.out.println("cevre = " + cevre);
    }
}
