package _Gun_03;

public class _07_Degiskenler {
    public static void main(String[] args) {

        int sayi;
        sayi=5;
        System.out.println(sayi);

        System.out.println("sayi");

        System.out.print("sayi=");
        System.out.println(sayi);

        System.out.println("sayi="+sayi);

    }
}
